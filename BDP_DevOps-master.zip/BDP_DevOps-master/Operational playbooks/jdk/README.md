Due to limitations with Github and non-availability of Github LFS

Please download Oracle prior from the Oracle JDK archive download page

https://www.oracle.com/technetwork/java/javase/downloads/java-archive-javase8-2177648.html

And place into roles/deployjdk/files
