Extra variables to be delcared when creating the keystore requires subject content. Those to be included and declared variables else otherwise will be empty are

C=Country=DE
L=Locale=Ratingen

O=Vodafone Group Services Limited
OU=BDP
ST=null/empty
CN=vgddp151hr.dc-ratingen.de

Playbook example will look like below as follows;

ansible-playbook -i /root/ansible/playbooks/inventory --ask-vault-pass --extra-vars "hosts=vgddp273hr.dc-ratingen.de" --extra-vars "city=Ratingen" --extra-vars "country=DE" new-host-ssl-onboard.yml -v

Validation and certificate output once CSR submitted to CA

vgddp151hr:root:/opt/cloudera/security/x509 $ openssl x509 -in vgddp151hr.pem -noout -text | grep -i subject
        Subject: C=DE, ST=Unknown, L=Ratingen, O=Vodafone Group Services Limited, OU=BDP, CN=vgddp151hr.dc-ratingen.de
        Subject Public Key Info:
            X509v3 Subject Key Identifier:
            X509v3 Subject Alternative Name:
