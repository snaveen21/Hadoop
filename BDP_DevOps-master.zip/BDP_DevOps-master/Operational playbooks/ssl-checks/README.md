ssl-check.yml playbook is for a current snapshot of the cluster estate, capturing just raw SSL certificate dates to be outputted in MI format

ssl-CHECK-DATE.yml playbook is for a potential forward planning in advance if cluster wide certificate exchange is require such as new internal CA such as moving from verisign to digicert and vis versa etc

ssl-CHECK-NOW.yml playbook outputs certificates which have expired NOW