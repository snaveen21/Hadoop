# BDP_DevOps
BDP Ansible playbooks for Operational tasks

https://confluence.sp.vodafone.com/x/_rkjC
