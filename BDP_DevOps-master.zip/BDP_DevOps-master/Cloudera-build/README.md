Ansible Cloudera Playbook
=========================

Note: MySQL is not configured or populated by Ansible. You need to run the necessary scripts to do this yourself.

SERVER HOSTNAMES MUST BE THEIR FULL FQDNs
SCM AND MASTER SERVERS MUST HAVE DB CONNECTIVITY

Set-up
------

1) Clone one of the existing inventories:

```
cp -r inventory/{lab,newservice}
```

2) Modify the variables in `inventory/newservice/group_vars/all` to match your environment.

3) Add the relevant servers to the inventory (`inventory/newservice/inventory`)

4) Add server, root and intermediate certificates to `certificates/newservice/`

4) Ensure you are able to SSH to the servers cleanly as root (ssh config correct and ssh keys installed):
`ping module`

5) Complete prerequisites: https://confluence.sp.vodafone.com/display/BDA1/For+RHEL+7.X

6) Run Ansible!

```
ansible-playbook -i inventory/newservice playbook.yml
```

7) Check in the Cloudera Manager console for progress. Ansible only deploys the _task_ that creates the cluster; it doesn't monitor for whether or not the deployment is successful.

8) Unfortunatley the KTS deployment will always fail. Once it does, connect to the active KTS server and run:

```
rsync -zav --exclude .ssl /var/lib/keytrustee/.keytrustee <passive kts server>:/var/lib/keytrustee/
```

Then retry the command from the GUI.

Notes
-----

###Self-signed certificates
Self-signed certificates can be used as long as they are signed against a root certificate and included in `certificates/newservice`. Ansible/Cloudera doesn't care if the root is itself trusted anywhere else.

###Test-Cleanup
When cleaning up you will have to manually empty (not delete) the contents of  `/var/lib/keytrustee`
