#!/bin/bash

echo $(date +%Y-%m-%dT%H:%M:%S.%N%z) "MySQL Backup Starting"

if [ -e /root/.my.cnf ]; then
        echo $(date +%Y-%m-%dT%H:%M:%S.%N%z) "/root/.my.cnf used for MySQL backup username and password"
else
        echo $(date +%Y-%m-%dT%H:%M:%S.%N%z) "/root/.my.cnf does not exist. Exiting..."
        exit 1
fi

BACKUPROOT=/root/backup
BACKUPDIR=$BACKUPROOT/$(date +%Y/%m/%d)

echo $(date +%Y-%m-%dT%H:%M:%S.%N%z) "Creating $BACKUPDIR for backing up"

mkdir -p $BACKUPDIR

if [ $? -eq 0 ]; then
        echo $(date +%Y-%m-%dT%H:%M:%S.%N%z) "$BACKUPDIR created"
else
        errcode=$?
        echo $(date +%Y-%m-%dT%H:%M:%S.%N%z) "$BACKUPDIR not created"
        exit $errcode
fi

errorcode=0

echo $(date +%Y-%m-%dT%H:%M:%S.%N%z) "Backing up amon"

mysqldump --single-transaction amon > $BACKUPDIR/amon_backup

errorcode=$(($errorcode + $?))

echo $(date +%Y-%m-%dT%H:%M:%S.%N%z) "Backing up hue"

mysqldump --single-transaction hue > $BACKUPDIR/hue_backup

errorcode=$(($errorcode + $?))

echo $(date +%Y-%m-%dT%H:%M:%S.%N%z) "Backing up metastore"

mysqldump --single-transaction metastore > $BACKUPDIR/metastore_backup

errorcode=$(($errorcode + $?))
# Disabled under C266
#echo $(date +%Y-%m-%dT%H:%M:%S.%N%z) "Backing up nav"
#
#mysqldump --single-transaction nav > $BACKUPDIR/nav_backup
#
#errorcode=$(($errorcode + $?))
#
#echo $(date +%Y-%m-%dT%H:%M:%S.%N%z) "Backing up navms"
#
mysqldump --single-transaction navms > $BACKUPDIR/navms_backup

errorcode=$(($errorcode + $?))

echo $(date +%Y-%m-%dT%H:%M:%S.%N%z) "Backing up oozie"

mysqldump --single-transaction oozie > $BACKUPDIR/oozie_backup

errorcode=$(($errorcode + $?))

echo $(date +%Y-%m-%dT%H:%M:%S.%N%z) "Backing up rman"

mysqldump --single-transaction rman > $BACKUPDIR/rman_backup

errorcode=$(($errorcode + $?))

echo $(date +%Y-%m-%dT%H:%M:%S.%N%z) "Backing up scm"

mysqldump --single-transaction scm > $BACKUPDIR/scm_backup

errorcode=$(($errorcode + $?))

echo $(date +%Y-%m-%dT%H:%M:%S.%N%z) "Backing up sentry"

mysqldump --single-transaction sentry > $BACKUPDIR/sentry_backup

#if [ $errorcode -eq 0 ]; then
#       echo $(date +%Y-%m-%dT%H:%M:%S.%N%z) "No errors detected, deleting old backups using command: rm -rf $BACKUPROOT/$(date +%Y/%m -d "2 months ago")"
#       rm -rf $BACKUPROOT/$(date +%Y/%m -d "2 months ago")
#       if [ $(ls -A $BACKUPROOT/$(date +%Y -d "2 months ago")) ]; then
#               echo $(date +%Y-%m-%dT%H:%M:%S.%N%z) "$BACKUPROOT/$(date +%Y -d "2 months ago") is not empty"
#       else
#               echo $(date +%Y-%m-%dT%H:%M:%S.%N%z) "Also deleting $BACKUPROOT/$(date +%Y -d "2 months ago")"
#               rmdir $BACKUPROOT/$(date +%Y -d "2 months ago")
#       fi
#else
#       echo $(date +%Y-%m-%dT%H:%M:%S.%N%z) "Errors detected in the backups. Exiting..."
#       exit $errorcode
#fi
exit 0


