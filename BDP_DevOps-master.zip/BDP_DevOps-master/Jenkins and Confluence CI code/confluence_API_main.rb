require 'net/https'
require 'json'
require 'io/console'
require 'highline/import'
require_relative 'confluence_API'

def authentication (username="", prompt="Please enter your password: ", confluence_base_url="https://confluence.ordsvy.gov.uk/")
  puts "please enter your username: "
  @username = username
  @username = gets.chomp

  @password = ask(prompt) { |q| q.echo = "*" }

  @confluence_base_url = confluence_base_url
end

def gets_confluence_page_content
  authentication

  puts "please enter the page name you are after"
  page_name = gets.chomp.gsub!(' ', '+')
  uri = URI.parse("#{@confluence_base_url}display/~DWong/#{page_name}")
  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true
  http.verify_mode = OpenSSL::SSL::VERIFY_NONE

  request = Net::HTTP::Get.new(uri.request_uri)
  request.basic_auth(@username, @password)

  response = http.request(request)
  response
end


def creates_new_confluence_page_using_post
  #authentication
  api = ConfluenceAPI.new('Username', 'Password', 'https://confluence.ordsvy.gov.uk/')

  space_key = '~DWong'

  page_name_array = ['steve4', 'steve5', 'steve6', 'steve8888888831888887', 'test page']
  page_name_array.each do |page_name|
    begin
      if api.create_page('Release Management POC Page', space_key, page_name, "<p>This is a new page 3</p>")
        puts "#{page_name} created successfully"
      end
    rescue Exception => e
      puts e
    end
  end

  puts api.get_page_id('Release Management POC Page', '~DWong')
end


creates_new_confluence_page_using_post

#capture pageId= via rel="canonical" href= under/within page source

#home page id = pageId=39912632 "Darren Wong’s Home"