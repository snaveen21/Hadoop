require 'rest-client'
require 'net/http'
require 'json'
require 'nokogiri'

class JenkinsBuildInfo

  JENKINS_URI = URI.parse("https://osvm1143.ordsvy.gov.uk:443")

  def initialize (jenkins_release_job)
    @jenkins_release_job = jenkins_release_job
  end

  def last_successful_build_jenkins_url()

    #@jenkins_release_job = "HighwaysDev%20-%20Flyway%20Scripts%20to%20Nexus"j

    http = Net::HTTP.start(JENKINS_URI.host, JENKINS_URI.port, :use_ssl => true, :verify_mode => OpenSSL::SSL::VERIFY_NONE)
    request = Net::HTTP::Get.new("/view/Release%20Jobs/job/#{@jenkins_release_job}/api/json")

    response = http.request(request)
    response_text = response.body
    response_json = JSON.parse(response_text)

    response_json["lastCompletedBuild"]["url"]

    successful_build_url = response_json["lastSuccessfulBuild"]["url"]
    puts successful_build_url
    # jenkins_request = Net::HTTP::Get.new("#{successful_build_url}api/json")

    # jenkins_response = http.request(jenkins_request)
    # jenkins_request_text = jenkins_response.body

    # jenkins_request_json = JSON.parse(jenkins_request_text)

    # puts jenkins_request_json["actions"][0]["parameters"][2]["tag"]
    # puts jenkins_request_json["url"]


  end

end

j = JenkinsBuildInfo.new("HighwaysDev%20-%20Flyway%20Scripts%20to%20Nexus")
j.last_successful_build_jenkins_url