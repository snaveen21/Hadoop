class ConfluenceAPI

  def initialize (username, password, base_url, jenkins_release_job, jenkins_base_url)
    @username = username
    @password = password
    @base_url = base_url
    uri = URI.parse(base_url)
    @http = Net::HTTP.start(uri.host, uri.port, :use_ssl => true, :verify_mode => OpenSSL::SSL::VERIFY_NONE)

    @jenkins_base_url = jenkins_base_url
    @jenkins_release_job = jenkins_release_job.gsub!(' ', '%20')
    jenkins_uri = URI.parse(jenkins_base_url)
    @http_jenkins = Net::HTTP.start(jenkins_uri.host, jenkins_uri.port, :use_ssl => true, :verify_mode => OpenSSL::SSL::VERIFY_NONE)
  end

  def create_page (space_key, build_url, free_text)
    uri = URI.parse("#{@base_url}rest/api/content/")

    request = Net::HTTP::Post.new(uri.request_uri)
    request.basic_auth(@username, @password)

    request["Content-Type"] = "application/json"
    request["Accept"] = "application/json"

    body_hash = {
        "type": "page",
        "ancestors": [{
                          "type": "page",
                          "id": get_page_id(space_key)
                      }],
        "title": "#{@jenkins_release_job.gsub!('%20', ' ')} - #{artifact_version(build_url)}",
        "space": {
            "key": space_key
        },
        "body": {
            "storage": {
                "value": "#{last_Successful_build_jenkins_info(build_url)}<p>Release consists of:</p><ol>#{free_text}</ol>",
                "representation": "storage"
            }
        }
    }

    request.body = body_hash.to_json

    response = @http.request(request)

    if response.code == "200"
      true
    else
      raise Exception.new("Error creating #{@jenkins_release_job.gsub!('%20', ' ')}, returned #{response.code} error report = #{response.body}")
    end
  end

  def get_page_id (space_key)
    uri = URI.parse("#{@base_url}rest/api/content?title=#{@jenkins_release_job}&spaceKey=#{space_key}&expand=history")

    request = Net::HTTP::Get.new(uri.request_uri)
    request.basic_auth(@username, @password)

    response = @http.request(request)

    if response.code == "200"
      response_text = response.body
      response_json = JSON.parse(response_text)

      response_json["results"][0]["id"] #hash

    else
      raise Exception.new("Error retrieving PageID as response code returned #{response.body}")
    end
  end

  def last_Successful_build_jenkins_url
    request = Net::HTTP::Get.new("/view/Release%20Jobs/job/#{@jenkins_release_job}/api/json")

    response = @http_jenkins.request(request)
    response_text = response.body
    response_json = JSON.parse(response_text)

    response_json["lastCompletedBuild"]["url"]
  end

  def last_Successful_build_jenkins_info(build_url)
    request = Net::HTTP::Get.new("#{build_url}api/json")

    response = @http_jenkins.request(request)
    jenkins_request_text = response.body

    jenkins_request_json = JSON.parse(jenkins_request_text)

    build_tag = jenkins_request_json["actions"][0]["parameters"][2]["tag"]
    full_build_url = jenkins_request_json["url"]

    "<p>Release created at SVN revision: #{build_tag}</p><p>Built by Jenkins job: <A HREF=\"#{full_build_url}\">#{full_build_url}</A></p>"
  end

  def artifact_version(build_url)
    request = Net::HTTP::Get.new("#{build_url}api/json")

    response = @http_jenkins.request(request)
    jenkins_request_text = response.body

    jenkins_request_json = JSON.parse(jenkins_request_text)

    jenkins_request_json["actions"][0]["parameters"][2]["tag"]
  end

end



