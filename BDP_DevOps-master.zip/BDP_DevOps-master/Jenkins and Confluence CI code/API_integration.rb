require 'net/https'
require 'json'
require 'io/console'
require 'highline/import'
require_relative 'confluence_API.rb'

username = "#{ARGV[3]}"
password = "#{ARGV[0]}"
base_url = 'https://confluence.ordsvy.gov.uk/'
jenkins_base_url = "https://osvm1143.ordsvy.gov.uk:443"
jenkins_release_job = "#{ARGV[2]}"
space_key = 'HIG'
free_text = "#{ARGV[1]}"


test = ConfluenceAPI.new(username, password, base_url, jenkins_release_job, jenkins_base_url)

test.create_page(space_key, test.last_Successful_build_jenkins_url, free_text)

